cdo -f nc input,mygrid netcdf_file.nc < grids_germany_daily_evapo_p_19910101.asc
